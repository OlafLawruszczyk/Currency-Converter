public class Currency {
    double eurToPln = 4.69;
    double plnToEur = 0.21;
    double usdToPln = 4.53;
    double plnToUsd = 0.22;
    double eurToUsd = 1.03;
    double usdToEur = 0.97;

}
