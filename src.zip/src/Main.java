import java.util.Scanner;

public class Main {
    public static void main(String[] args) {

        Currency exchangeRate = new Currency();

        Scanner scanner = new Scanner(System.in);

        boolean shouldContinue = true;

        while (shouldContinue) {
            System.out.println("Enter the currency you want to convert: PLN, EUR, USD");
            String currencyToConvert = scanner.next();
            String currencyToConvertU = currencyToConvert.toUpperCase();
            System.out.println();

            System.out.println("Enter the amount in " + currencyToConvert.toUpperCase() + ":");
            double amount = scanner.nextDouble();
            System.out.println();

            System.out.println("Enter the currency you want to convert to: PLN, EUR, USD");
            String currencyToConvertTo = scanner.next();
            String currencyToConvertToU = currencyToConvertTo.toUpperCase();
            System.out.println();

            String exchange = currencyToConvertU + currencyToConvertToU;
            double result = 0;
            switch (exchange) {
                case "EURPLN":
                    result = amount * exchangeRate.eurToPln;
                    System.out.println(amount + " " + currencyToConvertU + " is an equivalent of " + result + " " + currencyToConvertToU);
                    break;
                case "EURUSD":
                    result = amount * exchangeRate.eurToUsd;
                    System.out.println(amount + " " + currencyToConvertU + " is an equivalent of " + result + " " + currencyToConvertToU);
                    break;
                case "PLNEUR":
                    result = amount * exchangeRate.plnToEur;
                    System.out.println(amount + " " + currencyToConvertU + " is an equivalent of " + result + " " + currencyToConvertToU);
                    break;
                case "PLNUSD":
                    result = amount * exchangeRate.plnToUsd;
                    System.out.println(amount + " " + currencyToConvertU + " is an equivalent of " + result + " " + currencyToConvertToU);
                    break;
                case "USDEUR":
                    result = amount * exchangeRate.usdToEur;
                    System.out.println(amount + " " + currencyToConvertU + " is an equivalent of " + result + " " + currencyToConvertToU);
                    break;
                case "USDPLN":
                    result = amount * exchangeRate.usdToPln;
                    System.out.println(amount + " " + currencyToConvertU + " is an equivalent of " + result + " " + currencyToConvertToU);
                    break;
                default:
                    System.out.println("Invalid data. Try again.");
                    break;
            }
            System.out.println();
        }
    }
}